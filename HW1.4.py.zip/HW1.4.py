# 4. Пользователь вводит целое положительное число. Найдите самую большую цифру в числе. Для решения используйте цикл while и арифметические операции.
num = (int(input("Fill in any positive integer: "))
n = num
max_digit = n % 10
while n:
    a = n % 10
    if a > max_digit:
        max_digit = a
        if max_digit == 10:
            break
    n = n // 10

print(f"The biggest number in {num} is {max_digit}")
