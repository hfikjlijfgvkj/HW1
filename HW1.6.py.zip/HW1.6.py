a = int(input("Fill in the first number: "))
b = int(input("Fill in the second number: "))
days = 1
while a < b:
    a = a * 1.1
    days = days + 1
print(days)