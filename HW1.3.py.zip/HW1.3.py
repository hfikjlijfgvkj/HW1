# 3. Узнайте у пользователя число n. Найдите сумму чисел n + nn + nnn. Например, пользователь ввёл число 3. Считаем 3 + 33 + 333 = 369.

num = int(input('Fill in a number fron 1 to 9: '))
num_three = num + num*11 + num*111
print(num_three)