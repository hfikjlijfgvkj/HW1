# 2. Пользователь вводит время в секундах. Переведите время в часы, минуты, секунды и выведите в формате чч:мм:сс. Используйте форматирование строк.


time_in_seconds = int(input("Fill in time in seonds: "))
hours = (int(time_in_seconds // 60 // 60))
time_in_seconds = time_in_seconds - hours * 60 * 60
minutes = (int(time_in_seconds / 60))
seconds = (int(time_in_seconds - minutes * 60))
print(f'{hours:02}:{minutes:02}:{seconds:02}')
