# 5. Запросите у пользователя значения выручки и издержек фирмы. Определите, с каким финансовым результатом работает фирма. Например, прибыль — выручка больше издержек, или убыток — издержки больше выручки. Выведите соответствующее сообщение.

revenue = int(input("Fill in your revenue: "))
expenses = int(input("Fill in your expenses: "))
profit = revenue - expenses

if profit > 0:
    print("Your profit is", profit)
elif profit == 0:
    print("You haven't got any profit(")
else:
    loose = expenses - revenue
    print("You've lost", loose)

# 6. Если фирма отработала с прибылью, вычислите рентабельность выручки. Это отношение прибыли к выручке. Далее запросите численность сотрудников фирмы и определите прибыль фирмы в расчёте на одного сотрудника.

marginality = profit / revenue
employees = float(input("How many employees have you got? "))
profit_per_employee = marginality / employees
print("The profit per an amloyee is", profit_per_employee)
